import {
  lazy,
  Suspense,
  useEffect,
  useState,
} from "react";

import {
  ArrowRight,
  LockKeyhole,
  Sparkles,
} from "lucide-react";

import { supabase } from "./lib/supabase";

import "./AppV2.css";

const AppV2 = lazy(() => import("./AppV2"));


/* ==========================================================
   ROFFLE
   APP ENTRY / LOGIN
   ========================================================== */


function PrototypeLoading() {
  return (
    <main className="roffle-auth-loading">
      <span>Loading ROFFLE...</span>
    </main>
  );
}


function RoffleLogo() {
  return (
    <a
      className="roffle-logo"
      href="/"
      aria-label="ROFFLE home"
    >
      <span className="logo-mark">
        R
      </span>

      <span className="logo-word">
        ROFFLE
      </span>
    </a>
  );
}


function LoginPage() {
  const [
    signingIn,
    setSigningIn,
  ] = useState(false);

  const [
    signedIn,
    setSignedIn,
  ] = useState(false);

  const [
    authError,
    setAuthError,
  ] = useState<string | null>(
    null
  );


  useEffect(() => {
    let active = true;

    void supabase.auth
      .getSession()
      .then(({ data }) => {
        if (!active) {
          return;
        }

        setSignedIn(
          Boolean(data.session)
        );
      });

    const {
      data: {
        subscription,
      },
    } =
      supabase.auth.onAuthStateChange(
        (_event, session) => {
          if (!active) {
            return;
          }

          setSignedIn(
            Boolean(session)
          );
        }
      );

    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);


  const signInWithGoogle =
    async () => {
      setSigningIn(true);
      setAuthError(null);

      const { error } =
        await supabase.auth
          .signInWithOAuth({
            provider: "google",

            options: {
              redirectTo:
                `${window.location.origin}/?v=2`,
            },
          });

      if (error) {
        setAuthError(
          error.message
        );

        setSigningIn(false);
      }
    };


  const continueToRoffle =
    () => {
      window.location.assign(
        "/?v=2"
      );
    };


  return (
    <div className="roffle-auth-page">
      <style>
        {`
          .roffle-auth-page {
            min-height: 100vh;
            background:
              radial-gradient(
                circle at 85% 8%,
                rgba(255, 90, 31, 0.10),
                transparent 31rem
              ),
              radial-gradient(
                circle at 10% 95%,
                rgba(17, 17, 17, 0.035),
                transparent 30rem
              ),
              var(--bg);
          }

          .roffle-auth-header {
            background: rgba(17, 17, 17, 0.97);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          }

          .roffle-auth-header-shell {
            width: min(1120px, calc(100% - 40px));
            height: 72px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
          }

          .roffle-auth-browse {
            color: #b8b8b4;
            font-size: 12px;
            font-weight: 700;
            transition: color 140ms ease;
          }

          .roffle-auth-browse:hover {
            color: #fff;
          }

          .roffle-auth-main {
            width: min(1120px, calc(100% - 40px));
            min-height: calc(100vh - 72px);
            margin: 0 auto;
            padding: 64px 0;
            display: grid;
            grid-template-columns: minmax(0, 1.1fr) minmax(360px, 430px);
            align-items: center;
            gap: 88px;
          }

          .roffle-auth-intro {
            max-width: 610px;
          }

          .roffle-auth-kicker {
            margin-bottom: 14px;
            display: inline-flex;
            align-items: center;
            gap: 7px;
            color: var(--accent);
            font-size: 10px;
            font-weight: 900;
            letter-spacing: 0.15em;
            text-transform: uppercase;
          }

          .roffle-auth-intro h1 {
            max-width: 590px;
            margin: 0;
            color: #171717;
            font-size: clamp(50px, 6.5vw, 82px);
            font-weight: 880;
            line-height: 0.92;
            letter-spacing: -0.065em;
          }

          .roffle-auth-intro p {
            max-width: 500px;
            margin: 25px 0 0;
            color: var(--text-soft);
            font-size: 15px;
            line-height: 1.7;
          }

          .roffle-auth-caption {
            margin-top: 30px;
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-muted);
            font-size: 11px;
            font-weight: 650;
          }

          .roffle-auth-caption span:first-child {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--accent);
            box-shadow: 0 0 0 4px var(--accent-soft);
          }

          .roffle-login-card {
            padding: 34px;
            border: 1px solid var(--border);
            border-radius: 22px;
            background: #fff;
            box-shadow:
              0 3px 12px rgba(0, 0, 0, 0.025),
              0 28px 70px rgba(0, 0, 0, 0.05);
          }

          .roffle-login-orb {
            width: 52px;
            height: 52px;
            margin-bottom: 24px;
            display: grid;
            place-items: center;
            border-radius: 15px;
            background: #111;
            color: #fff;
          }

          .roffle-login-card h2 {
            margin: 0;
            color: #171717;
            font-size: 29px;
            font-weight: 850;
            letter-spacing: -0.045em;
          }

          .roffle-login-card > p {
            margin: 9px 0 25px;
            color: var(--text-soft);
            font-size: 12px;
            line-height: 1.6;
          }

          .roffle-google-button,
          .roffle-continue-button {
            width: 100%;
            min-height: 50px;
            padding: 0 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 11px;
            border: 0;
            border-radius: 13px;
            background: var(--accent);
            color: #fff;
            font-size: 13px;
            font-weight: 800;
            box-shadow: 0 9px 24px rgba(255, 90, 31, 0.18);
            transition:
              transform 140ms ease,
              background 140ms ease;
          }

          .roffle-google-button:hover,
          .roffle-continue-button:hover {
            transform: translateY(-1px);
            background: #ee4f16;
          }

          .roffle-google-button:disabled {
            opacity: 0.65;
            cursor: wait;
            transform: none;
          }

          .roffle-google-mark {
            width: 24px;
            height: 24px;
            display: grid;
            place-items: center;
            border-radius: 7px;
            background: #fff;
            color: #171717;
            font-size: 13px;
            font-weight: 900;
          }

          .roffle-auth-divider {
            margin: 23px 0;
            display: flex;
            align-items: center;
            gap: 12px;
            color: #aaa;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
          }

          .roffle-auth-divider::before,
          .roffle-auth-divider::after {
            content: "";
            height: 1px;
            flex: 1;
            background: var(--border);
          }

          .roffle-auth-guest {
            width: 100%;
            min-height: 46px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            border: 1px solid var(--border);
            border-radius: 12px;
            background: var(--surface-soft);
            color: #282828;
            padding: 0 15px;
            font-size: 12px;
            font-weight: 750;
          }

          .roffle-auth-guest:hover {
            border-color: #c9c9c3;
            background: #fff;
          }

          .roffle-auth-error {
            margin: 15px 0 0;
            padding: 11px 12px;
            border: 1px solid rgba(210, 60, 35, 0.18);
            border-radius: 10px;
            background: #fff3ef;
            color: #b23820;
            font-size: 11px;
            line-height: 1.45;
          }

          .roffle-auth-footnote {
            margin-top: 20px;
            display: flex;
            align-items: flex-start;
            gap: 8px;
            color: #999994;
            font-size: 10px;
            line-height: 1.5;
          }

          .roffle-auth-footnote svg {
            flex: 0 0 auto;
            margin-top: 1px;
          }

          .roffle-auth-loading {
            min-height: 100vh;
            display: grid;
            place-items: center;
            background: #0d0d0e;
            color: #8a8a8f;
            font-size: 12px;
            font-weight: 700;
          }

          @media (max-width: 850px) {
            .roffle-auth-main {
              grid-template-columns: 1fr;
              gap: 44px;
              padding: 46px 0 64px;
            }

            .roffle-auth-intro {
              max-width: 700px;
            }

            .roffle-auth-intro h1 {
              font-size: clamp(48px, 12vw, 72px);
            }

            .roffle-login-card {
              width: 100%;
              max-width: 520px;
            }
          }

          @media (max-width: 520px) {
            .roffle-auth-header-shell,
            .roffle-auth-main {
              width: min(100% - 28px, 1120px);
            }

            .roffle-auth-main {
              padding-top: 36px;
            }

            .roffle-auth-browse {
              font-size: 11px;
            }

            .roffle-auth-intro h1 {
              font-size: 48px;
            }

            .roffle-auth-intro p {
              font-size: 13px;
            }

            .roffle-login-card {
              padding: 25px 20px;
              border-radius: 18px;
            }
          }
        `}
      </style>

      <header className="roffle-auth-header">
        <div className="roffle-auth-header-shell">
          <RoffleLogo />

          <a
            className="roffle-auth-browse"
            href="/?v=2"
          >
            Browse ROFFLE
          </a>
        </div>
      </header>

      <main className="roffle-auth-main">
        <section className="roffle-auth-intro">
          <div className="roffle-auth-kicker">
            <Sparkles size={14} />
            wtf internet nonsense
          </div>

          <h1>
            Welcome back to the internet.
          </h1>

          <p>
            Sign in to post the weird stuff,
            questionable videos, and things
            you probably should have kept to
            yourself.
          </p>

          <div className="roffle-auth-caption">
            <span />

            <span>
              Lurking remains completely free.
            </span>
          </div>
        </section>

        <section className="roffle-login-card">
          <div className="roffle-login-orb">
            <LockKeyhole size={22} />
          </div>

          <h2>
            Log in to ROFFLE
          </h2>

          <p>
            One click. No elaborate onboarding
            ritual. We have nonsense to get to.
          </p>

          {signedIn ? (
            <button
              className="roffle-continue-button"
              type="button"
              onClick={
                continueToRoffle
              }
            >
              Continue to ROFFLE

              <ArrowRight size={17} />
            </button>
          ) : (
            <button
              className="roffle-google-button"
              type="button"
              disabled={signingIn}
              onClick={() => {
                void signInWithGoogle();
              }}
            >
              <span className="roffle-google-mark">
                G
              </span>

              {signingIn
                ? "Opening Google..."
                : "Continue with Google"}
            </button>
          )}

          <div className="roffle-auth-divider">
            or
          </div>

          <a
            className="roffle-auth-guest"
            href="/?v=2"
          >
            Continue without an account

            <ArrowRight size={16} />
          </a>

          {authError && (
            <div className="roffle-auth-error">
              {authError}
            </div>
          )}

          <div className="roffle-auth-footnote">
            <LockKeyhole size={13} />

            <span>
              Authentication is handled through
              Supabase OAuth. ROFFLE never sees
              your Google password.
            </span>
          </div>
        </section>
      </main>
    </div>
  );
}


function App() {
  const params =
    new URLSearchParams(
      window.location.search
    );

  const version =
    params
      .get("v")
      ?.toLowerCase();

  if (
    version === "2" ||
    version === "v2"
  ) {
    return (
      <Suspense
        fallback={
          <PrototypeLoading />
        }
      >
        <AppV2 />
      </Suspense>
    );
  }

  return <LoginPage />;
}


export default App;